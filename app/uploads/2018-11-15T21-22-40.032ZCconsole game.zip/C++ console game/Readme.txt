Make sure "level_1.txt" is in the same file as "Game.exe".

I didn't know how to make game screen bigger when opening directly through "Game.exe",
so how I've done it is by making shortcut of "Game.exe" and changing font size to 12x16.

"Moving speed" stands for the refresh speed so the higher it is the slower game works

"Difficulty" option doesn't work, because I didn't want to do it :p